var foo = require("./purchaseOrderF20-fixed");

var assert = require("assert");
var sinon = require("sinon");

/*---------------------------------------------------------*/
/*-------------------- DD-PATH TESTING --------------------*/
/*---------------------------------------------------------*/
describe("DD-PATH TESTING", function () {
    //F1 getAgeFactor
    describe("F1 getAgeFactor", function () {
        var age = [
            { in: 15, exp: 0 }, //path 1 – 2 – 13 – end
            { in: 20, exp: 10 }, //path 1 – 3 – 4 – 13 – end
            { in: 30, exp: 15 }, //path 1 – 3 – 5 – 6 – 13 – end
            { in: 40, exp: 20 }, //path 1 – 3 – 5 – 7 – 8 – 13 – end
            { in: 50, exp: 45 }, //path 1 – 3 – 5 – 7 – 9 – 10 – 13 – end
            { in: 70, exp: 25 }, //path 1 – 3 – 5 – 7 – 9 – 11 – 12 – 13 – end
        ];

        age.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                var myVar = {}
                myVar.age = test.in;
                var myResult = foo.getAgeFactor(myVar);
                assert.strictEqual(myResult, test.exp)
            });
        });
    });

    //F2 getBalanceFactor
    describe("F2 getBalanceFactor", function () {
        var balance = [
            { in: 0, exp: 0 }, //path 1 – 2 – 13 – end
            { in: 90, exp: 5 }, //path 1 – 3 – 4 – 13 – end
            { in: 300, exp: 15 }, //path 1 – 3 – 5 – 6 – 13 – end
            { in: 750, exp: 25 }, //path 1 – 3 – 5 – 7 – 8 – 13 – end
            { in: 2000, exp: 65 }, //path 1 – 3 – 5 – 7 – 9 – 10 – 13 – end
            { in: 4000, exp: 150 }, //path 1 – 3 – 5 – 7 – 9 – 11 – 12 – 13 – end
        ];

        balance.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                var myVar = {}
                myVar.balance = test.in;
                var myResult = foo.getBalanceFactor(myVar);
                assert.strictEqual(myResult, test.exp)
            });
        });
    });

    //F3 accountStatus
    describe("F3 accountStatus", function () {
        var balance = [
            { in: 0, exp: "invalid" }, //path 1 – 2 – end
            { in: 100, exp: "adverse" }, //path 1 – 3 – 4 – end
            { in: 300, exp: "acceptable" }, //path 1 – 3 – 5 – 6 – end
            { in: 750, exp: "good" }, //path 1 – 3 – 5 – 7 – 8 – end
            { in: 2000, exp: "excellent" }, //path 1 – 3 – 5 – 7 – 9 – 10 – end
        ];

        balance.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                //use stubs to spoof the ageFactor and balanceFactor values
                var stub1 = sinon.stub(foo, "getAgeFactor");
                stub1.returns(1); //use "1" for easy multiplication
                var stub2 = sinon.stub(foo, "getBalanceFactor");
                stub2.returns(test.in);
                var myResult = foo.accountStatus(null);
                stub1.restore();
                stub2.restore();
                assert.strictEqual(myResult, test.exp);

            });
        });
    });

    //F4 creditStatus
    describe("F4 creditStatus", function () {
        var ins = [
            { in: -1, in2: "restricted", exp: "invalid" }, //path 1 – 2 – 3 – 4 – 7 – 8 – end
            { in: 60, in2: "restricted", exp: "adverse" }, //path 1 – 2 – 3 – 5 – 7 – 9 – end
            { in: 90, in2: "default", exp: "good" }, //path 1 – 2 – 3 – 5 – 6 – 7 – 8 – end
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2, function () {
                var myVar = {}
                myVar.creditScore = test.in;
                var myResult = foo.creditStatus(myVar, test.in2);
                assert.strictEqual(myResult, test.exp);
            });
        });
    });

    //F5 productStatus and names match
    describe("F5 productStatus - names match", function () {
        var ins1 = [
            { in: null, invQuantity: 60, threshold: 500, exp: "invalid" }]; //path 1 – 2 – 10 – end (skip loop)
        var ins2 =[    
            { item1: {invName: "test", invQuantity: 0}, threshold: 500, prodName: "test", exp: "soldout" }]; //path 1 – 2 – 3 – 5 – 6 – end (zero loops)
        var ins3 =[    
            { item1: {invName: "wrongitem", invQuantity: 60}, item2: {invName: "test", invQuantity: 60}, threshold: 500, prodName: "test", exp: "limited" }]; //path 1 – 2 – 3 – 4 – 2 – 3 – 5 – 7 – 8 – end (one loop)
        var ins4 =[    
            { item1: {invName: "wrongitem", invQuantity: 900}, item2: {invName: "wrongitem2", invQuantity: 900}, item3: {invName: "test", invQuantity: 900}, threshold: 500, prodName: "test", exp: "available" }]; //path 1 – 2 – 3 – 4 – 2 – 3 – 4 – 2 – 3 – 5 – 7 – 9 – end (multiple loops)
            
        //path 1 – 2 – 10 – end (skip loop)
        ins1.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.threshold, function () {
                var myVar = [];
                var product = test.in;
                var inv = {};
                inv.name = "a";
                inv.q = test.invQuantity;
                myVar.push(inv);
                var myResult = foo.productStatus(product, myVar, test.threshold);
                assert.strictEqual(myResult, test.exp);
            });
        });

        //path 1 – 2 – 3 – 5 – 6 – end (zero loops)
        ins2.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.invQuantity + " and " + test.threshold, function () {
                var myVar = [];
                var product = test.prodName;
                var inv1 = {};
                inv1.name = test.item1.invName;
                inv1.q = test.item1.invQuantity;
                myVar.push(inv1);
                var myResult = foo.productStatus(product, myVar, test.threshold);
                assert.strictEqual(myResult, test.exp);
            });
        });

        //path 1 – 2 – 3 – 4 – 2 – 3 – 5 – 7 – 8 – end (one loop)
        ins3.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.item2.invQuantity + " and " + test.threshold, function () {
                var myVar = [];
                var product = test.prodName;
                var inv1 = {};
                inv1.name = test.item1.invName;
                inv1.q = test.item1.invQuantity;
                var inv2 = {};
                inv2.name = test.item2.invName;
                inv2.q = test.item2.invQuantity;
                myVar.push(inv1);
                myVar.push(inv2);
                var myResult = foo.productStatus(product, myVar, test.threshold);
                assert.strictEqual(myResult, test.exp);
            });
        });

        //path 1 – 2 – 3 – 4 – 2 – 3 – 4 – 2 – 3 – 5 – 7 – 9 – end (multiple loops)
        ins4.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.item3.invQuantity + " and " + test.threshold, function () {
                var myVar = [];
                var product = test.prodName;
                var inv1 = {};
                inv1.name = test.item1.invName;
                inv1.q = test.item1.invQuantity;
                var inv2 = {};
                inv2.name = test.item2.invName;
                inv2.q = test.item2.invQuantity;
                var inv3 = {};
                inv3.name = test.item3.invName;
                inv3.q = test.item3.invQuantity;
                myVar.push(inv1);
                myVar.push(inv2);
                myVar.push(inv3);
                var myResult = foo.productStatus(product, myVar, test.threshold);
                assert.strictEqual(myResult, test.exp);
            });
        });
    });

    //F6 orderHandling
    describe("F6 orderHandling", function () {
        var ins = [
            { in: "invalid", in2: "", in3: "", exp: "rejected" }, //path 1 – 2 – end
            { in: "excellent", in2: "good", in3: "", exp: "accepted" }, //path 1 – 2 – 3 – 4 – end
            { in: "acceptable", in2: "adverse", in3: "available", exp: "underReview" }, //path 1 – 2 – 3 – 5 – 6 – end
            { in: "adverse", in2: "good", in3: "limited", exp: "pending" }, //path 1 – 2 – 3 – 5 – 7 – 8 – end
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2 + " and " + test.in3, function () {
                var stub1 = sinon.stub(foo, "accountStatus");
                stub1.returns(test.in);
                var stub2 = sinon.stub(foo, "creditStatus");
                stub2.returns(test.in2);
                var stub3 = sinon.stub(foo, "productStatus");
                stub3.returns(test.in3);
                var myVar = {}
                myVar.ins = test.in;
                var myResult = foo.orderHandling(myVar);
                stub1.restore();
                stub2.restore();
                stub3.restore();
                assert.strictEqual(myResult, test.exp);

            });
        });
    });
});

describe.only('Bonus: MM-Path Tests', function () {

    var tests = [
        { mm_path: "Path1", clientAccount: { age: 15, balance: 0, creditScore: -1 }, prodName: "test", item: [{ name: "badName", q: 0 }], inventoryThreshold: 500, creditCheckMode: "restricted", af: 0, bf: 0, as: "invalid", cs: "invalid", ps: "invalid", oh: "rejected", },
        { mm_path: "Path2", clientAccount: { age: 50, balance: 4000, creditScore: 90 }, prodName: "test", item: [{ name: "test", q: 900 }], inventoryThreshold: 500, creditCheckMode: "default", af: 45, bf: 150, as: "excellent", cs: "good", ps: "available", oh: "accepted" },
        { mm_path: "Path3", clientAccount: { age: 40, balance: 300, creditScore: 60 }, prodName: "test", item: [{ name: "test", q: 900 }], inventoryThreshold: 500, creditCheckMode: "restricted", af: 20, bf: 15, as: "acceptable", cs: "adverse", ps: "available", oh: "underReview" },
        { mm_path: "Path4", clientAccount: { age: 30, balance: 750, creditScore: 90 }, prodName: "test", item: [{ name: "test", q: 60 }], inventoryThreshold: 500, creditCheckMode: "default", af: 15, bf: 25, as: "acceptable", cs: "good", ps: "limited", oh: "pending" },
        { mm_path: "Path5", clientAccount: { age: 70, balance: 90, creditScore: -1 }, prodName: "test", item: [{ name: "badName", q: 500 }], inventoryThreshold: 500, creditCheckMode: "default", af: 25, bf: 5, as: "adverse", cs: "invalid", ps: "invalid", oh: "rejected" },
        { mm_path: "Path6", clientAccount: { age: 20, balance: 2000, creditScore: -1 }, prodName: "test", item: [{ name: "test", q: 0 }], inventoryThreshold: 500, creditCheckMode: "default", af: 10, bf: 65, as: "good", cs: "invalid", ps: "soldout", oh: "rejected" }
    ];

    tests.forEach(function(test) {
        it('MM-Path Test: ' + test.mm_path, function() {
            assert.strictEqual(foo.getAgeFactor(test.clientAccount), test.af);
            assert.strictEqual(foo.getBalanceFactor(test.clientAccount), test.bf);
            assert.strictEqual(foo.accountStatus(test.clientAccount), test.as);
            assert.strictEqual(foo.creditStatus(test.clientAccount, test.creditCheckMode), test.cs);
            assert.strictEqual(foo.productStatus(test.prodName, test.item, test.inventoryThreshold), test.ps);
            assert.strictEqual(foo.orderHandling(test.clientAccount, test.prodName, test.item, test.inventoryThreshold, test.creditCheckMode), test.oh)
        });
    });

});